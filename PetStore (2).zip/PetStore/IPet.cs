﻿namespace FSDN.PetStore
{
    internal interface IPet
    {
        void ShowAffection();
        
    }
}
