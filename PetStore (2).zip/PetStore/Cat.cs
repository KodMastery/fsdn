﻿namespace FSDN.PetStore
{
    internal class Cat : Animal
    {
        internal string Type { get; set; }
        internal Cat(string name, int age, double price, string type) : base(name, age, price)
        {
            Type = type;
        }

        internal Cat() {}

        public override void ShowAffection()
        {
            Console.WriteLine($"Hug the cat <3 {Name}");
        }

    }
}
