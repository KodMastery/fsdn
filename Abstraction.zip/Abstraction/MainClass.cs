﻿namespace FSDN.Abstraction
{
    internal class MainClass
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Heyo");
            IAnimal cat = new Cat();
        }
    }
}
