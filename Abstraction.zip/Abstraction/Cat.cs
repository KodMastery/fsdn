﻿namespace FSDN.Abstraction
{
    internal class Cat : IAnimal
    {
        public void Speak()
        {
            Console.WriteLine("Meeooow");
        }

        public string Eat(int calories)
        {
            return "Cat is eating: " + calories;
        }

    }
}
