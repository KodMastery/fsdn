﻿namespace FSDN.Abstraction
{
    internal interface IAnimal
    {
        void Speak();
        string Eat(int calories);

    }
}
