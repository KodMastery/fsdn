﻿namespace FSDN.PetStore
{
    internal class MainClass
    {
        public static void Main(string[] args)
        {
            /*
             * GOALS:
             * 0. Let's make our PetStore :3
             * 1. interface IPet -> [ShowAffection() SetPrice() GetPrice() GetAge() SetAge() GetName(), SetName()]
             * 2. class Animal : IPet -> { name, age, price } [IPet methods]
             * 3. class Cat : Animal -> [override GetName(), override GetAge()]
             * 4. We want to make two cats
             * 5. These cats will have Owners
             * 6. PetOwner -> struct {name, surname, email}
             */
            Console.WriteLine("Our PetStore");
            Animal mathilda = new Cat("Mathilda", 2, 90.2, "persion");
            mathilda.ShowAffection();
        }
    }
}