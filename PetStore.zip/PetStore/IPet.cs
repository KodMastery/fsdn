﻿namespace FSDN.PetStore
{
    internal interface IPet
    {
        void ShowAffection();
        void SetPrice(double price);
        double GetPrice();
        void SetAge(int age);
        int GetAge();
        void SetName(string name);
        string GetName();
    }
}
