﻿namespace FSDN.PetStore
{
    internal class Animal : IPet
    {
        protected string name;
        protected int age;
        protected double price;

        internal Animal(string name, int age, double price)
        {
            this.name = name;
            this.age = age;
            this.price = price;
        }

        internal Animal()
        {

        }

        public int GetAge()
        {
            return age;
        }

        public string GetName()
        {
            return name;
        }

        public double GetPrice()
        {
            return price;
        }

        public void SetAge(int age)
        {
            this.age = age;
        }

        public void SetName(string name)
        {
            this.name = name;
        }

        public void SetPrice(double price)
        {
           this.price = price;
        }

        public virtual void ShowAffection()
        {
           Console.WriteLine($"Hug the pet <3 {name}");
        }
    }
}
