﻿namespace FSDN.PetStore
{
    internal class Cat : Animal
    {
        private string type;
        internal Cat(string name, int age, double price, string type) : base(name, age, price)
        {
            this.type = type;
        }

        internal Cat()
        {

        }

        internal string GetType()
        {
            return type;
        }

        public override void ShowAffection()
        {
            Console.WriteLine($"Hug the cat <3 {name}");
        }

    }
}
